<?php
session_start();
include("../app/config.php");

// Pastikan user login
if (!isset($_SESSION['user_email'])) {
    header('Location: loginUser.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Tambah Artikel - Skillora</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Lucida Sans', sans-serif;
        }

        .form-container {
            background: #fff;
            border-radius: 16px;
            padding: 40px;
            max-width: 700px;
            margin: 50px auto;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
        }

        .btn-custom {
            background-color: rgba(72, 0, 124, 1);
            color: white;
            border: none;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background-color: rgba(72, 0, 124, 0.66);
            color: black;
        }

        textarea {
            resize: none;
        }

        .page-title {
            text-align: center;
            font-weight: bold;
            margin-bottom: 30px;
            color: #333;
        }

        .back-link {
            text-decoration: none;
            color: #6c757d;
        }

        .back-link:hover {
            color: #000;
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-dark bg-dark px-4">
        <a class="navbar-brand fw-bold" href="dashboard_artikel.php">Lekitra<span class="text-info">;</span></a>
        <div class="ms-auto">
            <a href="dashboard.php" class="back-link"><i class="bi bi-arrow-left-circle"></i> Kembali</a>
        </div>
    </nav>

    <!-- Form Tambah Artikel -->
    <div class="form-container">
        <h3 class="page-title">Tambah Artikel Baru</h3>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form action="../app/add.php" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="judul" class="form-label fw-semibold">Judul Artikel</label>
                <input type="text" name="judul" id="judul" class="form-control" placeholder="Masukkan judul artikel" required>
            </div>

            <div class="mb-3">
                <label for="penulis" class="form-label fw-semibold">Penulis Artikel</label>
                <input type="text" name="penulis" id="penulis" class="form-control" placeholder="Masukkan penulis artikel" required>
            </div>

            <div class="mb-3">
                <label for="konten" class="form-label fw-semibold">Isi Artikel</label>
                <textarea name="konten" id="konten" rows="6" class="form-control" placeholder="Tulis isi artikel di sini..." required></textarea>
            </div>

            <div class="mb-3">
                <label for="gambar" class="form-label fw-semibold">Gambar</label>
                <input type="file" name="gambar" id="gambar" class="form-control" accept=".jpg,.jpeg,.png,.gif" required>
            </div>

            <div class="d-grid gap-2 mt-4">
                <button type="submit" class="btn btn-custom py-2 fw-bold">
                    <i class="bi bi-save"></i> Simpan Artikel
                </button>
            </div>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>