<?php
session_start();
include("../app/config.php");

// Pastikan user login
if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit;
}

// Ambil data artikel dengan jumlah like
$query = "SELECT a.*, 
          (SELECT COUNT(*) FROM artikel_likes WHERE artikel_id = a.id) AS total_likes
          FROM artikel a
          ORDER BY tanggal DESC";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Terjadi kesalahan pada query: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - Skillora</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background-color: #fff;
            font-family: 'Lucida Sans', sans-serif;
        }

        .navbar {
            background-color: #212529;
        }

        .btn-custom {
            background-color: rgba(72, 0, 124, 1);
            color: #fff;
            border: none;
            transition: 0.3s;
        }

        .btn-custom:hover {
            background-color: rgba(72, 0, 124, 0.66);
            color: black;
        }

        .card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease;
            cursor: pointer;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-img-top {
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;
            height: 200px;
            object-fit: cover;
        }

        .card-footer {
            background-color: transparent;
        }

        .empty-message {
            padding: 50px 0;
            color: #6c757d;
            text-align: center;
        }

        h3 {
            font-family: 'Merriweather', serif;
        }

        .like-count {
            color: #e83e8c;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 5px;
        }
    </style>
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark px-4">
        <a class="navbar-brand fw-bold" href="#">Lekitra<span class="text-info">;</span></a>
        <div class="ms-auto">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="#">Profile</a></li>
                <li class="nav-item"><a class="nav-link text-danger" href="../app/logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <!-- Main Container -->
    <div class="container my-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="fw-bold text-dark mb-0">Dashboard Artikel</h3>
            <a href="addArtikel.php" class="btn btn-custom">
                <i class="bi bi-plus-circle"></i> Tambah Artikel
            </a>
        </div>

        <?php if (mysqli_num_rows($result) > 0): ?>
            <div class="row g-4">
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <div class="col-md-4">
                        <div class="card h-100" onclick="window.location.href='artikel.php?id=<?= $row['id'] ?>'">
                            <?php if (!empty($row['gambar'])): ?>
                                <img src="<?= htmlspecialchars($row['gambar']) ?>" class="card-img-top" alt="<?= htmlspecialchars($row['judul']) ?>">
                            <?php else: ?>
                                <img src="https://via.placeholder.com/400x200?text=No+Image" class="card-img-top" alt="No Image">
                            <?php endif; ?>

                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($row['judul']) ?></h5>
                                <p class="text-muted small mb-2">
                                    <i class="bi bi-calendar"></i> <?= htmlspecialchars(date("d M Y", strtotime($row['tanggal']))) ?>
                                </p>
                                <p class="card-text"><?= substr(htmlspecialchars($row['konten']), 0, 100) ?>...</p>
                            </div>

                            <div class="card-footer d-flex justify-content-between align-items-center">

                                <div>
                                    <a href="../app/update.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-info">
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </a>
                                    <a href="../app/delete.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger"
                                        onclick="return confirm('Yakin ingin menghapus artikel ini?')">
                                        <i class="bi bi-trash"></i> Hapus
                                    </a>
                                </div>
                                <div class="like-count">
                                    <i class="bi bi-heart-fill"></i> <?= $row['total_likes'] ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="empty-message">
                <i class="bi bi-journal-x" style="font-size: 3rem;"></i>
                <h5 class="mt-3">Belum ada artikel yang ditambahkan.</h5>
                <p>Mulai dengan menambahkan artikel pertama kamu.</p>
                <a href="addArtikel.php" class="btn btn-custom mt-3">
                    <i class="bi bi-plus-circle"></i> Tambah Artikel Sekarang
                </a>
            </div>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>