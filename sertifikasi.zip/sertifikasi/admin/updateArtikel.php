
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Artikel - Skillora</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Lucida Sans', sans-serif;
        }
        .form-container {
            background: #fff;
            border-radius: 16px;
            padding: 40px;
            max-width: 700px;
            margin: 50px auto;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
        }
        .btn-custom {
            background-color: rgba(72, 0, 124, 1);
            color: white;
            border: none;
            transition: 0.3s;
        }
        .btn-custom:hover {
            background-color: rgba(72, 0, 124, 0.66);
            color: black;
        }
        textarea { resize: none; }
        .page-title {
            text-align: center;
            font-weight: bold;
            margin-bottom: 30px;
            color: #333;
        }
        .preview img {
            max-height: 180px;
            border-radius: 10px;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-dark bg-dark px-4">
        <a class="navbar-brand fw-bold" href="../../dashboard_artikel.php">Lekitra<span class="text-info">;</span></a>
        <div class="ms-auto">
            <a href="../admin/dashboard.php" class="text-secondary text-decoration-none"><i class="bi bi-arrow-left-circle"></i> Kembali</a>
        </div>
    </nav>

    <div class="form-container">
        <h3 class="page-title">Edit Artikel</h3>

        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label class="form-label fw-semibold">Judul Artikel</label>
                <input type="text" name="judul" class="form-control" 
                    value="<?= htmlspecialchars($judul) ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Penulis Artikel</label>
                <input type="text" name="penulis" class="form-control" 
                    value="<?= htmlspecialchars($penulis) ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label fw-semibold">Isi Artikel</label>
                <textarea name="konten" rows="6" class="form-control" required><?= htmlspecialchars($konten) ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Ganti Gambar (Opsional)</label>
                <input type="file" name="gambar" class="form-control" accept=".jpg,.jpeg,.png,.gif">
                <?php if (!empty($gambar_lama)): ?>
                    <div class="preview mt-3 text-center">
                        <p class="text-muted small mb-2">Gambar saat ini:</p>
                        <img src="<?= htmlspecialchars($gambar_lama) ?>" alt="Gambar Artikel">
                    </div>
                <?php endif; ?>
            </div>

            <div class="d-grid gap-2 mt-4">
                <button type="submit" class="btn btn-custom py-2 fw-bold">
                    <i class="bi bi-save"></i> Simpan Perubahan
                </button>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
