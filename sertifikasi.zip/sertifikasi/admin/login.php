<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        .form-container {
            width: 100%;
            max-width: 450px;
            height: 500px;
            padding: 2em;
            background: linear-gradient(to bottom right, #e3f2fd, #fff);
            border-radius: 16px;
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
            margin: 1em auto;
            border: 2px solid #bbdefb;
        }

        .form-container h1 {
            text-align: center;
            padding-bottom: 20px;
            justify-content: center;
        }
        .btn {
                display: inline-block;
                padding: 0.8em 1.5em;
                font-weight: 600;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.2s ease-in-out;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }
        
        .btn-primary {
            background: linear-gradient(to right, #2c2eb2d5, #e040fb); 
            color: white;
        }

    </style>
</head>

<body>
    <div class="form-container sign-up-container shadow">
        <form action="../app/login.php" method="POST">
            <h1>Login</h1>
            <div class="mt-4 text-center" style="width: 100%">
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" class="form-control" id="email" placeholder="email@gmail.com" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
            </div>
            <center><a href="register.php" class="login" style="color:Blue;">Belum memiliki akun? Daftar</a></center>
            <br>
            <br>
            <center><button type="submit" name="login-btn" class="btn btn-primary btn-custom">Sign In</button></center>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>