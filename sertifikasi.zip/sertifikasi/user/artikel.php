<?php
session_start();
include("../app/config.php");

// Pastikan user login
if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit;
}

$id = intval($_GET['id']); // Sanitasi input

// Ambil data artikel dari database
$query = "SELECT * FROM artikel WHERE id = $id";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Terjadi kesalahan pada query: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artikel</title>

    <!-- Bootstrap & Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Google -->
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Poppins:wght@400;500&family=Lato:wght@400&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #fafafa;
            margin: 0;
            padding: 0;
        }

        .conten {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin: 40px auto;
            max-width: 750px;
            height: auto;
            background: #fff;
            padding: 40px;
            border-radius: 14px;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
        }

        h1 {
            font-family: 'Playfair Display', serif;
            font-weight: 600;
            text-align: center;
            color: #2c2c2c;
            margin-bottom: 20px;
        }

        img {
            width: 100%;
            max-width: 750px;
            height: auto;
            border-radius: 10px;
            margin-bottom: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.08);
        }

        .meta-info {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 15px;
            color: #555;
        }

        .meta-info .date {
            font-size: 0.95rem;
            color: #888;
            margin-bottom: 6px;
        }

        .meta-info .author {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 1rem;
            font-weight: 500;
            color: #4a006e;
            background-color: #f7f2fa;
            padding: 6px 14px;
            border-radius: 20px;
            box-shadow: 0 2px 4px rgba(72, 0, 124, 0.1);
        }

        .meta-info .author i {
            color: #4a006e;
        }

        p {
            font-family: 'Lato', sans-serif;
            text-align: justify;
            line-height: 1.9;
            color: #444;
            margin-top: 20px;
            overflow-wrap: break-word;
            max-width: 750px;
            text-indent: 30px;
        }

        .btn-custom {
            background-color: rgba(72, 0, 124, 1) !important;
            color: #fff !important;
            border: none;
            transition: 0.3s;
            font-weight: 500;
            padding: 8px 20px;
            border-radius: 8px;
            margin-top: 30px;
        }

        .btn-custom:hover {
            background-color: rgba(72, 0, 124, 0.7) !important;
            color: #000 !important;
        }
    </style>
</head>

<?php include('../admin/header.php'); ?>

<body>
    <?php if (mysqli_num_rows($result) > 0): ?>
        <?php $row = mysqli_fetch_assoc($result); ?>
        <div class="conten">
            <h1><?= htmlspecialchars($row['judul']) ?></h1>

            <?php if (!empty($row['gambar'])): ?>
                <img src="<?= htmlspecialchars($row['gambar']) ?>" alt="<?= htmlspecialchars($row['judul']) ?>">
            <?php endif; ?>

            <div class="meta-info">
                <div class="date">
                    <i class="bi bi-calendar"></i> <?= htmlspecialchars(date("d M Y", strtotime($row['tanggal']))) ?>
                </div>
                <div class="author">
                    <i class="bi bi-pencil-fill"></i>
                    Created by <?= htmlspecialchars($row['penulis']) ?>
                </div>
            </div>

            <p><?= nl2br(trim(htmlspecialchars($row['konten']))) ?></p>

            <a href="dashboard.php" class="btn btn-custom">
                <i class="bi bi-arrow-left"></i> Kembali
            </a>
        </div>
    <?php endif; ?>
</body>
</html>
