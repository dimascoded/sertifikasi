<?php
session_start();
include("../app/config.php");

// Pastikan user sudah login
if (!isset($_SESSION['email'])) {
    header('Location: ../admin/login.php');
    exit;
}

$email = $_SESSION['email'];

// 🔹 Ambil nama user dari tabel users
$userQuery = "SELECT username FROM user WHERE email = '$email' LIMIT 1";
$userResult = mysqli_query($conn, $userQuery);
$user = mysqli_fetch_assoc($userResult);
$username = $user ? $user['username'] : 'User';

// 🔹 Ambil semua artikel dan status like user
$query = "SELECT a.*, 
          (SELECT COUNT(*) FROM artikel_likes WHERE artikel_id = a.id) AS total_likes,
          (SELECT COUNT(*) FROM artikel_likes WHERE artikel_id = a.id AND email = '$email') AS user_liked
          FROM artikel a
          ORDER BY tanggal DESC";
$result = mysqli_query($conn, $query);

if (!$result) {
    die('Terjadi kesalahan pada query: ' . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Artikel - Skillora</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

<style>
body {
  background-color: #fff;
  font-family: 'Poppins', sans-serif;
}

.navbar {
  background-color: #212529;
}

.btn-custom {
  background-color: rgba(72, 0, 124, 1);
  color: #fff;
  border: none;
  transition: 0.3s;
}

.btn-custom:hover {
  background-color: rgba(72, 0, 124, 0.66);
  color: black;
}

.card {
  border: none;
  border-radius: 12px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  transition: transform 0.2s ease;
  cursor: pointer;
  position: relative;
}

.card:hover {
  transform: translateY(-5px);
}

.card-img-top {
  border-top-left-radius: 12px;
  border-top-right-radius: 12px;
  height: 200px;
  object-fit: cover;
}

.like-btn {
  background: none;
  border: none;
  color: #6c757d;
  font-size: 1.2rem;
  cursor: pointer;
}

.like-btn.liked {
  color: #e83e8c;
}

.card-footer {
  background: transparent;
  border-top: none;
}

.greeting h3 {
  color: #48007C;
  font-weight: 600;
}
</style>
</head>
<body>

<!-- 🔹 Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark px-4">
  <a class="navbar-brand fw-bold" href="#">Lekitra<span class="text-info">;</span></a>
  <div class="ms-auto">
      <ul class="navbar-nav">
          <li class="nav-item"><a class="nav-link" href="..">Profile</a></li>
          <li class="nav-item"><a class="nav-link text-danger" href="../app/logout.php">Logout</a></li>
      </ul>
  </div>
</nav>

<!-- 🔹 Konten utama -->
<div class="container my-5">
  <div class="d-flex justify-content-between align-items-start mb-4 flex-wrap">
      <div class="greeting mb-3">
          <h3>Halo, <?= htmlspecialchars($username) ?> 👋</h3>
        <h3 class="fw-bold text-dark mb-0">Dashboard Artikel</h3>
      </div>
      
  </div>
  <?php if (mysqli_num_rows($result) > 0): ?>
  <div class="row g-4">
    <?php while ($row = mysqli_fetch_assoc($result)): ?>
      <div class="col-md-4">
        <div class="card h-100" data-link="artikel.php?id=<?= $row['id'] ?>">
          <?php if (!empty($row['gambar'])): ?>
            <img src="<?= htmlspecialchars($row['gambar']) ?>" class="card-img-top" alt="<?= htmlspecialchars($row['judul']) ?>">
          <?php else: ?>
            <img src="https://via.placeholder.com/400x200?text=No+Image" class="card-img-top" alt="No Image">
          <?php endif; ?>

          <div class="card-body">
            <h5 class="card-title"><?= htmlspecialchars($row['judul']) ?></h5>
            <p class="text-muted small mb-2">
              <i class="bi bi-calendar"></i> <?= htmlspecialchars(date("d M Y", strtotime($row['tanggal']))) ?>
            </p>
            <p class="card-text"><?= substr(htmlspecialchars($row['konten']), 0, 100) ?>...</p>
          </div>

          <div class="card-footer d-flex justify-content-between align-items-center">
            <small class="text-muted">Klik untuk baca</small>
            <button class="like-btn <?= $row['user_liked'] ? 'liked' : '' ?>"
                    data-id="<?= $row['id'] ?>"
                    onclick="event.stopPropagation(); handleLike(this)">
              <i class="bi bi-heart<?= $row['user_liked'] ? '-fill' : '' ?>"></i>
              <span class="like-count"><?= $row['total_likes'] ?></span>
            </button>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
  <?php else: ?>
    <div class="text-center text-muted mt-5">Belum ada artikel yang ditambahkan.</div>
  <?php endif; ?>
</div>

<!-- 🔹 Script interaksi -->
<script>
// Klik kartu → buka artikel
document.querySelectorAll(".card").forEach(card => {
  card.addEventListener("click", () => {
    const link = card.getAttribute("data-link");
    if (link) window.location.href = link;
  });
});

// Klik tombol like → kirim AJAX ke likes.php
async function handleLike(btn) {
  const id = btn.dataset.id;
  const formData = new FormData();
  formData.append("artikel_id", id);

  const response = await fetch("../app/likes.php", {
    method: "POST",
    body: formData
  });

  const data = await response.json();

  if (data.success) {
    const icon = btn.querySelector("i");
    const count = btn.querySelector(".like-count");
    let current = parseInt(count.textContent);
    if (data.liked) {
      btn.classList.add("liked");
      icon.classList.replace("bi-heart", "bi-heart-fill");
      count.textContent = current + 1;
    } else {
      btn.classList.remove("liked");
      icon.classList.replace("bi-heart-fill", "bi-heart");
      count.textContent = current - 1;
    }
  }
}
</script>

</body>
</html>
