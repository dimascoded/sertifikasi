<?php
session_start();
include('config.php');

// Pastikan user login
if (!isset($_SESSION['user_email'])) {
    header('Location: ../../login.php');
    exit;
}

// Cek ID artikel
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ../../dashboard.php?error=" . urlencode("Artikel tidak ditemukan."));
    exit;
}

$id = intval($_GET['id']);
$error = "";

// Ambil data artikel
$stmt = $conn->prepare("SELECT * FROM artikel WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$artikel = $result->fetch_assoc();
$stmt->close();

// Jika artikel tidak ditemukan
if (!$artikel) {
    header("Location: ../../dashboard.php?error=" . urlencode("Artikel tidak ditemukan."));
    exit;
}

// Inisialisasi variabel untuk view
$judul = $artikel['judul'];
$penulis = $artikel['penulis'];
$konten = $artikel['konten'];
$gambar_lama = $artikel['gambar'];

// Proses jika form dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = trim($_POST['judul'] ?? '');
    $penulis = trim($_POST['penulis'] ?? '');
    $konten = trim($_POST['konten'] ?? '');
    $tanggal = date('Y-m-d');
    $gambar_baru = $gambar_lama;

    // Upload gambar baru
    if (!empty($_FILES['gambar']['name'])) {
        $target_dir = "../../uploads/";
        if (!file_exists($target_dir)) mkdir($target_dir, 0777, true);

        $file_name = basename($_FILES['gambar']['name']);
        $target_file = $target_dir . time() . "_" . $file_name;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($file_type, $allowed)) {
            if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
                if (!empty($gambar_lama) && file_exists($gambar_lama)) unlink($gambar_lama);
                $gambar_baru = $target_file;
            } else {
                $error = "Gagal mengupload gambar baru.";
            }
        } else {
            $error = "Format gambar tidak valid (hanya JPG, JPEG, PNG, GIF).";
        }
    }

    // Update ke database jika tidak ada error
    if (empty($error)) {
        $stmt = $conn->prepare("UPDATE artikel SET judul = ?, penulis = ?, konten = ?, tanggal = ?, gambar = ? WHERE id = ?");
        $stmt->bind_param("sssssi", $judul, $penulis, $konten, $tanggal, $gambar_baru, $id);

        if ($stmt->execute()) {
            header("Location: ../admin/dashboard.php?success=" . urlencode("Artikel berhasil diperbarui!"));
            exit;
        } else {
            $error = "Gagal memperbarui data: " . $conn->error;
        }
        $stmt->close();
    }
}

// Panggil view
include("../admin/updateArtikel.php");
