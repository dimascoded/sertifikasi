<?php
include('config.php');
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
}

// Eksekusi query hapus 
$result = mysqli_query($conn, "DELETE FROM artikel WHERE id = '$id'");

if ($result) {
    // Jika berhasil, arahkan ke logout
    header("Location: ../admin/dashboard.php");
    exit();
} else {
    echo "Gagal menghapus data: " . mysqli_error($conn);
}
