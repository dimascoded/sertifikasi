<?php
session_start();
include("config.php");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../admin/login.php');
    exit;
}

$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

$stmt = mysqli_prepare($conn, "SELECT email, username, password, role FROM user WHERE email = ?");
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

// Validasi login
if (!$user || !password_verify($password, $user['password'])) {
    header('Location: ../admin/login.php?error=' . urlencode('Email atau password salah'));
    exit;
}

// Set session
session_regenerate_id(true);
$_SESSION['username'] = $user['username'];
$_SESSION['email'] = $user['email'];
$_SESSION['role'] = $user['role'];

// Redirect sesuai role
if ($user['email'] === 'admin123@admin.com' ) {
    header('Location: ../admin/dashboard.php');
    exit;
} else {
    header('Location: ../user/dashboard.php');
    exit;
}
