<?php
session_start();
include("../app/config.php");

header('Content-Type: application/json'); // ← tambahkan ini

// Cek login
if (!isset($_SESSION['user_email'])) {
    http_response_code(403);
    echo json_encode(["success" => false, "message" => "User not logged in"]);
    exit;
}

$email = $_SESSION['user_email'];
$artikel_id = intval($_POST['artikel_id'] ?? 0);

if ($artikel_id <= 0) {
    echo json_encode(["success" => false, "message" => "Invalid article ID"]);
    exit;
}

// Cek apakah user sudah like
$check = $conn->prepare("SELECT 1 FROM artikel_likes WHERE artikel_id = ? AND email = ?");
$check->bind_param("is", $artikel_id, $email);
$check->execute();
$check_result = $check->get_result();

if ($check_result && $check_result->num_rows > 0) {
    // Jika sudah like → hapus (unlike)
    $del = $conn->prepare("DELETE FROM artikel_likes WHERE artikel_id = ? AND email = ?");
    $del->bind_param("is", $artikel_id, $email);
    if ($del->execute()) {
        echo json_encode(["success" => true, "liked" => false]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to unlike"]);
    }
    $del->close();
} else {
    // Jika belum → tambahkan like
    $ins = $conn->prepare("INSERT INTO artikel_likes (artikel_id, email) VALUES (?, ?)");
    $ins->bind_param("is", $artikel_id, $email);
    if ($ins->execute()) {
        echo json_encode(["success" => true, "liked" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to like"]);
    }
    $ins->close();
}

$check->close();
$conn->close();
?>
