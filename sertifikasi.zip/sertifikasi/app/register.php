<?php
session_start();
include("config.php");

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../admin/register.php');
    exit;
}

$username = trim($_POST['username'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

// Validasi dasar
if (empty($username) || empty($email) || empty($password)) {
    header('Location: ../admin/register.php?pesan=kosong');
    exit;
}

if (strlen($password) < 8) {
    header('Location: ../admin/register.php?pesan=gagal');
    exit;
}

// Cek apakah email sudah digunakan
$stmt = mysqli_prepare($conn, "SELECT email FROM users WHERE email = ?");
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
mysqli_stmt_store_result($stmt);

if (mysqli_stmt_num_rows($stmt) > 0) {
    mysqli_stmt_close($stmt);
    header("Location: ../admin/login.php?error=" . urlencode("Email sudah digunakan. Silakan login."));
    exit;
}
mysqli_stmt_close($stmt);

// Hash password dan simpan user baru
$password_hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = mysqli_prepare($conn, "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'user')");
mysqli_stmt_bind_param($stmt, "sss", $username, $email, $password_hash);

if (mysqli_stmt_execute($stmt)) {
    header("Location: ../admin/login.php?pesan=" . urlencode("Register berhasil, silakan login."));
} else {
    echo "Terjadi kesalahan: " . mysqli_error($conn);
}

mysqli_stmt_close($stmt);
exit();
?>
