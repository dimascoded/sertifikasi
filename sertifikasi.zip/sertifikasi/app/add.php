<?php
include('config.php');
// Proses form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = trim($_POST['judul'] ?? '');
    $penulis = trim($_POST['penulis'] ?? '');
    $konten = trim($_POST['konten'] ?? '');
    $tanggal = date('Y-m-d');
    $gambar = '';

    // Upload gambar jika ada
    if (!empty($_FILES['gambar']['name'])) {
        $target_dir = "../uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $file_name = basename($_FILES['gambar']['name']);
        $target_file = $target_dir . time() . "_" . $file_name;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Validasi jenis file
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        if (in_array($file_type, $allowed_types)) {
            if (move_uploaded_file($_FILES['gambar']['tmp_name'], $target_file)) {
                $gambar = $target_file;
            } else {
                $error = "Gagal mengupload gambar.";
            }
        } else {
            $error = "Hanya format JPG, JPEG, PNG, dan GIF yang diizinkan.";
        }
    }

    // Simpan ke database jika tidak ada error
    if (empty($error)) {
        $stmt = $conn->prepare("INSERT INTO artikel (judul, penulis, konten, tanggal, gambar) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $judul, $penulis, $konten, $tanggal, $gambar);
        if ($stmt->execute()) {
            header("Location: ../admin/dashboard.php?success=" . urlencode("Artikel berhasil ditambahkan!"));
            exit;
        } else {
            $error = "Terjadi kesalahan saat menyimpan data: " . $conn->error;
        }
        $stmt->close();
    }
}
?>