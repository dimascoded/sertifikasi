<?php
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $db_name = "artikel";

    $conn = new mysqli($hostname, $username, $password, $db_name);
?>